import React from 'react'

const Warranty = () => {
    return (
        <div>
            
        </div>
    )
}

export default Warranty
