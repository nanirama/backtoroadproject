import React from 'react'

const Customer = () => {
    return (
        <div>
            customer
        </div>
    )
}

export default Customer