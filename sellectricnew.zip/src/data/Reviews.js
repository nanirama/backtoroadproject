export const ReviewsData = [
	{
        "title": "William Edwards",
        "content": "Wow!! Backtoroad saved me 700 dollars with purchasing the transfer case i needed for my ford truck.It took a week to get it..but well worth the wait.It is in and works great.Much appreciation mike.",
        "rating": "5"
    },
	{
        "title": "Daniel Peacher",
        "content": "Friendly guys who made me the perfect abs up on the spot,I gave Darren my vehicle details he gave me a great price and I had my abs the next day, to easy. I recommend this trader to everyone.",
        "rating": "5"
    },
	{
        "title": "Roger Sanders",
        "content": "Best in the business I'm 78 years old and they treat me so nice. I was very hesitant to buy something of the web cause I was afraid of getting the wrong computer module. Called these folks, they said all they needed is the VIN number to my car and they got me the right part. Works like a charm. Excellent trustworthy service",
        "rating": "5"
    },
	{
        "title": "Kevin Davis",
        "content": "Part came in a reasonable time and looks like a good abs assembly ,saved money too. I would recommend backtoroad auto.",
        "rating": "5"
    },
	{
        "title": "Chris Higgins",
        "content": "I had trouble with local wrecking yards and their service. Phillips hooked me up today, so he gets his name in this. Well be returning again to find the piece that cannot be found. A real relief from the shoddy places down west. Got more than what i expected, ordered through phone, feels good.",
        "rating": "5"
    },
	{
        "title": "Victoria Steinfield",
        "content": "The front lower control arms on my 05 4Runner were so rusted/seized that it made an alignment impossible. Staff was friendly and knowledgeable and had the part I needed for cheaper than I thought. Great business. Highly recommend!!! ",
        "rating": "5"
    },
	{
        "title": "Benita Monroe",
        "content": "I ordered an ABS Assembly for my Toyota camry. It came very quickly and was in wonderful condition. They kept me updated through the entire process. From the order all the way through the delivery. I am beyond pleased with my experience with Joe.Thank you Backtoroad auto!!",
        "rating": "5"
    },
	{
        "title": "Chester Brown",
        "content": "I purchased some parts for 2004 land cruiser and I was getting ready to make the payment then the dude gave me a discount and dropped the price without me asking for a better deal. Professional and respectful. I usually call them if I need parts even though I live in Utah. ",
        "rating": "5"
    },
	{
        "title": "Patrick Burgois",
        "content": "They are helpful and knowledgeable. I called to get a window for my car right as they were about to close. Instead of being grumpy about it, they helped me in getting it..",
        "rating": "5"
    },
	{
        "title": "Jeremy Franklin",
        "content": "We received the abs computer and wanted to say thank you working fine",
        "rating": "5"
    },
	{
        "title": "Michelle Davis",
        "content": "As a Dodge owner this is the first place I check for parts and knowledge great staff and always helpful in all things DodgeðŸ'",
        "rating": "5"
    },
	{
        "title": "Michael Smith",
        "content": "certainly not the cheapest  but not the highest as well. i love my supra and they got me a good tranny runs great",
        "rating": "5"
    },
	{
        "title": "Ramirez Lopez",
        "content": "They had the part I need woohooo",
        "rating": "5"
    }
]