export const menuData = [
  { title: "Home", link: "/" },
  { title: "About", link: "/about" },
  { title: "Parts", link: "/parts" },
  { title: "Warranty", link: "/warranty" },
  { title: "Customer Service", link: "/customer" },
  { title: "Shipping & Handling", link: "/shipping-handling" },
  { title: "FAQ", link: "/faqs" },
]
