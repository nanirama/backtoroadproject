export const HomeJourneySoFarData = [
  {    
	newicon : "cog",
    title: "86754+",
    desc: "Parts Sold",
  },
  {
	newicon : "loc",
    title: "17+",
    desc: "Locations",
  },
  {
	newicon : "star",
    title: "4.6",
    desc: "Customer rating",
  },
  {
	newicon : "compass",
    title: "300+",
    desc: "Cities served",
  },
]
