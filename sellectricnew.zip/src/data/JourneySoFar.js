export const JourneySoFarData = [
  {
	newicon : "cog",
    title: "1045",
    desc: "Parts Sold",
  },
  {
	newicon : "user",
    title: "1045",
    desc: "Satisfied Customer",
  },
  {
	newicon : "star",
    title: "4.6",
    desc: "Customer rating",
  },
  {
	newicon : "compass",
    title: "3500+",
    desc: "Cities served",
  },
]
