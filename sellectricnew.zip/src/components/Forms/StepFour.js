import React from 'react'

const StepFour = () => {
    return (
        <div style={{ background: 'yellow', width: '100%', height: '100%', transition: '0.5s'}}>
            <h2>Thank you for thr enquiry. We will get back to you soon</h2>
        </div>
    )
}

export default StepFour
