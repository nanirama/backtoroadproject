#!/bin/bash
node_modules/.bin/gatsby build
node_modules/.bin/gatsby serve -H 0.0.0.0