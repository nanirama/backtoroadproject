import 'bootstrap/dist/css/bootstrap.min.css';
import './src/layout/layout.css'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

// export const onClientEntry = async () => {
//     if (typeof IntersectionObserver === "undefined") {
//       await import("intersection-observer")
//     }
//   }