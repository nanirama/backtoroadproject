import React from 'react'

const Faqs = () => {
    return (
        <div>
            
        </div>
    )
}

export default Faqs
